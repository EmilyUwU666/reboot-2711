#pragma once

#include <Windows.h>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <string>

namespace Reboot2711
{
    inline void ReportStartupFailure(const char* role, const char* detail)
    {
        const std::string message = std::string("Fortnite 27.11 ") + role + " initialization stopped.\n\n" + detail
            + "\n\nClose this game instance before retrying. This is an experimental Erbium-based build.";
        std::fprintf(stderr, "%s\n", message.c_str());
        // Logging must not turn a recoverable initialization failure into a crash.
        try
        {
            const auto path = std::filesystem::temp_directory_path()
                / (std::string("Reboot-27.11-") + role + "-startup.log");
            std::ofstream log(path, std::ios::app);
            log << message << '\n';
        }
        catch (...)
        {
        }
        MessageBoxA(nullptr, message.c_str(), "Reboot Launcher 27.11 - Erbium", MB_OK | MB_ICONERROR);
    }
}
