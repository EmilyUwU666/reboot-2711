#pragma once

#include <cstdint>
#include <limits>
#include <optional>
#include <string_view>

// This distribution targets one Fortnite release. Changelists are recorded,
// not guessed or used as a substitute for testing the actual executable.
namespace Reboot2711
{
    struct BuildVersion
    {
        unsigned EngineMajor = 0;
        unsigned EngineMinor = 0;
        std::uint64_t Changelist = 0;
        std::wstring_view Release;
    };

    inline bool ReadNumber(std::wstring_view text, std::size_t& pos, std::uint64_t& result)
    {
        const auto start = pos;
        result = 0;
        while (pos < text.size() && text[pos] >= L'0' && text[pos] <= L'9')
        {
            const auto digit = static_cast<unsigned>(text[pos] - L'0');
            if (result > ((std::numeric_limits<std::uint64_t>::max)() - digit) / 10)
                return false;
            result = result * 10 + digit;
            ++pos;
        }
        return pos != start;
    }

    inline bool Consume(std::wstring_view text, std::size_t& pos, wchar_t expected)
    {
        if (pos >= text.size() || text[pos] != expected)
            return false;
        ++pos;
        return true;
    }

    // UE's engine build string, e.g. 5.4.0-12345678+++Fortnite+Release-27.11.
    // The example changelist is illustrative, not an approved executable ID.
    inline std::optional<BuildVersion> ParseBuildVersion(std::wstring_view text)
    {
        std::size_t pos = 0;
        std::uint64_t major = 0, minor = 0, patch = 0, cl = 0;
        if (!ReadNumber(text, pos, major) || !Consume(text, pos, L'.') || !ReadNumber(text, pos, minor))
            return std::nullopt;
        if (pos < text.size() && text[pos] == L'.')
        {
            ++pos;
            if (!ReadNumber(text, pos, patch))
                return std::nullopt;
        }
        if (major > 99 || minor > 99 || patch > 999 || !Consume(text, pos, L'-') || !ReadNumber(text, pos, cl) || cl == 0)
            return std::nullopt;

        constexpr std::wstring_view marker = L"+++Fortnite+Release-";
        if (text.substr(pos, marker.size()) != marker)
            return std::nullopt;
        pos += marker.size();
        const auto release = text.substr(pos);
        std::uint64_t gameMajor = 0, gameMinor = 0;
        if (!ReadNumber(text, pos, gameMajor) || !Consume(text, pos, L'.') || !ReadNumber(text, pos, gameMinor) || pos != text.size())
            return std::nullopt;

        return BuildVersion{ static_cast<unsigned>(major), static_cast<unsigned>(minor), cl, release };
    }

    inline bool IsTarget(const BuildVersion& build)
    {
        // Erbium represents UE versions as decimals (5.3, 5.4, ...).
        // Reject future multi-digit UE5 minors that representation cannot encode.
        return build.Release == L"27.11" && build.EngineMajor == 5 && build.EngineMinor <= 9;
    }
}
