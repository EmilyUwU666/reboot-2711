#include "../Reboot2711/BuildVersion.h"
#include <cstdlib>
#include <iostream>
#include <string>

static int checks = 0;
static void Check(bool condition, const char* description)
{
    ++checks;
    if (!condition)
    {
        std::cerr << "FAIL: " << description << '\n';
        std::exit(1);
    }
}

int main()
{
    using namespace Reboot2711;
    // Synthetic build strings exercise the parser; they are not game validation.
    const auto target = ParseBuildVersion(L"5.4.0-12345678+++Fortnite+Release-27.11");
    Check(target.has_value() && IsTarget(*target), "27.11 recognized");
    Check(target->EngineMajor == 5 && target->EngineMinor == 4, "engine components retained");
    Check(target->Changelist == 12345678, "changelist retained");
    for (const auto input : { L"5.3.0-1+++Fortnite+Release-27.11", L"5.4-999+++Fortnite+Release-27.11" })
    {
        const auto value = ParseBuildVersion(input);
        Check(value.has_value() && IsTarget(*value), "patch component optional; CL not hard-coded");
    }
    for (const auto release : { L"27.10", L"27.00", L"27.110", L"27.011", L"28.00", L"20.40" })
    {
        const auto input = std::wstring(L"5.4.0-1+++Fortnite+Release-") + release;
        const auto value = ParseBuildVersion(input);
        Check(value.has_value() && !IsTarget(*value), "other releases rejected");
    }
    for (const auto input : { L"", L"27.11", L"5.4.0-0+++Fortnite+Release-27.11", L"5.4.0-1+++Fortnite+Release-27.11extra",
                             L"5.4.0-1+++Fortnite+Release-27.11.1", L"5.4.0-1+++Other+Release-27.11", L"5.4.0-x+++Fortnite+Release-27.11",
                             L"5.4.0-18446744073709551616+++Fortnite+Release-27.11", L"5.4.0-1+++Fortnite+Release-27.",
                             L"-5.4.0-1+++Fortnite+Release-27.11", L"5..0-1+++Fortnite+Release-27.11" })
        Check(!ParseBuildVersion(input).has_value(), "malformed or overflowing string rejected");
    for (const auto input : { L"4.27.0-1+++Fortnite+Release-27.11", L"6.0.0-1+++Fortnite+Release-27.11", L"5.10.0-1+++Fortnite+Release-27.11" })
    {
        const auto value = ParseBuildVersion(input);
        Check(value.has_value() && !IsTarget(*value), "unsupported engine encoding rejected");
    }
    std::cout << checks << " version-parser checks passed. Gameplay is not covered.\n";
}
