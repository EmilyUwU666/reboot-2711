# Fortnite 27.11 setup with Reboot Launcher

This is an experimental **Erbium-based** server/client project for Reboot
Launcher on **Windows x64**. It has not been compiled on Windows or verified
in-game in this environment. A successful build is the first remaining gate;
a complete multiplayer match is the next. It is not an iOS application.

## Build

1. Install Visual Studio 2022 or Build Tools 2022 with **Desktop development
   with C++**, the **v143 x64 C++ tools**, and a **Windows 10/11 SDK**.
2. Extract the entire source ZIP, including the SDK and dependency directories.
3. Run `BUILD.cmd`. Alternatively run `scripts/Build.ps1` from PowerShell.
4. A successful build creates both DLLs in `dist` and checks their x64 PE/DLL
   headers. Keep the server and client from the same build together.

You can also open `Erbium.sln` in Visual Studio and select **Release | x64**.
Those outputs appear in `build/Release`; the script copies them into `dist`.
The repository includes a Windows GitHub Actions workflow if you prefer to
build in your own repository. It has not been run for this package.

## Check your game installation

Use your existing, complete Fortnite 27.11 Windows installation. Both the
hosting instance and every joining player need matching game content.

Optional read-only preflight, in PowerShell from the source directory:

```powershell
.\scripts\Check-Install.ps1 -FortniteDirectory 'D:\Games\Fortnite-27.11'
```

When running from the built `dist` directory, use `./Check-Install.ps1` instead.
The check reads the executable's architecture and version metadata and checks
for the content directory. It does not verify every game file, launch the game,
or establish multiplayer compatibility. If metadata is missing, the script
reports that it cannot confirm the version.

## Select the paired DLLs

The labels below were checked against Reboot Launcher's source; their wording
may vary in a different release or language.

| Reboot Launcher setting | Select |
| --- | --- |
| Settings → Game server type | Custom |
| Settings → Game server | `Reboot-27.11-Server.dll` |
| Settings → Unreal engine patcher | `Reboot-27.11-Client.dll` |
| Game server port | `7777`, matching the source configuration |
| Installed game version | Your 27.11 Windows installation |

The custom Game server field is used for the host. The Unreal engine patcher
field is used for the playing client after login; this project's client DLL
also creates the Unreal console. Every joining player needs the matching client
DLL. Do not load both the embedded Reboot server DLL and this server DLL into
the same hosting process.

These DLLs perform in-game server/client work. They do not implement backend
login, account storage, the launcher, or an authentication redirect. You need
an existing 27.11-capable local/private backend setup. The Reload Backend
README names 27.11 as its tested Caldera-service version, but that statement
does not validate this complete server/client combination. See PROVENANCE.md.

## First local test

1. Start your backend and confirm that a 27.11 client can reach the lobby.
2. Start the hosting instance through Reboot Launcher. Wait for the server
   window to report that players can join. The Season 27 path opens
   `Athena_Terrain`.
3. Start a separate playing instance with the paired client DLL.
4. Use backend matchmaking, or use the Unreal console to enter
   `open 127.0.0.1:7777` for a host on the same PC. For a separate host, use its
   address. Direct connection still needs a working client login and runtime.
5. Confirm the player spawns. Use the server window's **Start Bus Early**
   button if needed. Test jumping from the bus, moving, shooting, pickups,
   inventory changes, building, damage, eliminations, and storm progression.
6. Join with a second player and test replication in both directions before
   considering the combination playable.

## If it fails

| Where it stops | Information to collect |
| --- | --- |
| Compilation | First compiler error and the surrounding MSBuild output |
| Before lobby | Launcher/backend errors; the server DLL has not yet started |
| Startup message box | The full message and `%TEMP%\Reboot-27.11-Server-startup.log` or `%TEMP%\Reboot-27.11-Client-startup.log` |
| Map loading or joining | Exact 27.11 changelist, server output, launcher output, and the relevant game log excerpt |
| Gameplay | Action that triggered the problem and whether both players reproduce it |

Game logs are normally under
`%LOCALAPPDATA%\FortniteGame\Saved\Logs`. Remove credentials and session tokens
from log excerpts before sharing them. SDK signature matches and a passed
preflight do not verify replication, maps, assets, or a full match.

## Configuration and limits

Edit `Erbium/Erbium/Public/Configuration.h` and rebuild **both** DLLs. Defaults:
solo playlist, port 7777, 30 ticks/second, Iris enabled, siphon disabled,
ordinary ammo/material consumption, late game disabled, join-in-progress
disabled, and automatic restart disabled.

The project retains upstream's newer-engine movement workarounds, which can
disable some sprinting/sliding/mantling behavior. Do not interpret a successful
connection as full feature parity with the original game. Live events,
quests/XP, Creative, cosmetics, and persistence are not validated here.

The version guard accepts the release label 27.11 and records the engine build
string. It does not whitelist a particular executable hash or assert that
every 27.11 hotfix/changelist works. Unknown core SDK bindings stop startup;
other unverified upstream paths can still fail during gameplay.
