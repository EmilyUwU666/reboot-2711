# Source and changes

This is an unofficial 27.11-targeted distribution of **Erbium**, prepared for
use as the custom server/client components in **Reboot Launcher**. It is not
a fork of the Project Reboot 3.0 server and does not claim upstream endorsement.

## Pinned base

- Repository: https://github.com/plooshi/Erbium
- Commit: `44568e08cbe411ba197d3e0e900685750d46afdc`
- License: GNU GPL version 3; original license text remains in `LICENSE`.
- Existing SDK, engine hooks, gameplay code, vendored ImGui/curl/zlib, and their
  notices remain from upstream. The SDK is Erbium's abstraction layer; this
  package contains no Fortnite executable or game asset files.

Preserve the license and notices and provide corresponding source when
redistributing a built derivative under the applicable GPL terms. The Windows
workflow produces a source artifact alongside its DLL artifact.

## Changes in this distribution

- Shared, exact 27.11 build-string validation before SDK binding initialization.
- Bound checks for the engine build string and handling for absent version
  discovery functions, name references, object classes, and core SDK bindings.
- Server/client startup messages and failure logs for the added checks.
- Guards for missing Iris configuration, missing game viewport/world, and an
  empty local-player list during server setup.
- Solo configuration with siphon disabled; both projects use the same config.
- Explicit x64 build target and distinct paired output names.
- Windows build script, PE/preflight checks, CI recipe, portable parser tests,
  setup instructions, and a validation record.

The Season 27 map path, Iris integration, UE5 reflection support, replication,
gameplay and client console originate from upstream. They were not newly
implemented or runtime-verified for this distribution.

## Integration sources inspected

- [Erbium SDK and version-specific bindings](https://github.com/plooshi/Erbium/blob/44568e08cbe411ba197d3e0e900685750d46afdc/SDK/Offsets.h)
- [Erbium server startup and map selection](https://github.com/plooshi/Erbium/blob/44568e08cbe411ba197d3e0e900685750d46afdc/Erbium/Erbium/Private/dllmain.cpp)
- [Erbium client](https://github.com/plooshi/Erbium/blob/44568e08cbe411ba197d3e0e900685750d46afdc/ErbiumClient/ErbiumClient/Private/dllmain.cpp)
- [Reboot Launcher DLL selection](https://github.com/Auties00/Reboot-Launcher/blob/c6f82298b167ef2076bb59dc621f13dc5bd8d390/gui/lib/src/controller/dll_controller.dart)
- [Reboot Launcher host/client loading](https://github.com/Auties00/Reboot-Launcher/blob/c6f82298b167ef2076bb59dc621f13dc5bd8d390/gui/lib/src/button/game_start_button.dart)
- [Reload Backend README](https://github.com/Project-Reload/Reload-Backend): external backend reference only; not included or tested with this package.

Project Reboot 3.0 was inspected first, including its `aboveS20` branch.
Erbium was chosen because its existing code includes Season 27-specific
bindings, newer replication handling, paired client changes, and the relevant
map selection. This selection does not turn upstream's partial support into
a verified release.
