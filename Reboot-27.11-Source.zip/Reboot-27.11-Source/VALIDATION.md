# Validation record

Prepared on 2026-09-13 from the pinned Erbium commit in PROVENANCE.md.

## Completed in this environment

- Compiled and ran `tests/build_version_tests.cpp` with GCC, C++17,
  `-Wall -Wextra -Werror -pedantic`: **25 checks passed**.
- The tests exercise exact 27.11 acceptance, engine/changelist extraction,
  neighboring releases, misleading release prefixes, malformed strings,
  numeric overflow, and unsupported engine encodings. Test changelists are
  synthetic. This is a parser test, not a test against a Fortnite executable.
- Parsed both Visual Studio project XML files and the added build-target
  file; checked that their literal source-file references exist.
- Reviewed the shared target definition and paired server/client build paths.
- `git diff --check` passed after the code changes.
- Inspected the pinned Reboot Launcher code for custom server selection and
  client patcher loading after login.

## Not completed

| Gate | Status |
| --- | --- |
| Windows/MSVC compilation of both complete DLLs | Not run; Windows MSVC/SDK tooling is unavailable here |
| PowerShell script execution and syntax verification by PowerShell | Not run; PowerShell is unavailable here; download attempt timed out |
| Windows CI workflow | Added, not executed |
| Validation against the user's actual 27.11 executable/changelist | Not run; executable not provided |
| Backend login and client redirect | External requirements, not tested |
| Server startup, map load, and player connection | Not run |
| Two-player replication, combat, inventory, building, and storm | Not run |
| Complete match or long-running stability | Not run |

No server/client DLL binary was built or supplied in this source ZIP. No
claim of a working or fully compatible 27.11 release is made. Upstream itself
describes support for newer seasons as partial.

The added guards catch particular initialization failures; they do not verify
the correctness of a nonzero address or cover every upstream failure path.
Next, build on Windows using `BUILD.cmd` or run the provided workflow, then
follow the local multiplayer test in SETUP.md. Keep the build output and the
first failing runtime log if either stage fails.

To rerun the portable parser tests:

```sh
g++ -std=c++17 -Wall -Wextra -Werror -pedantic tests/build_version_tests.cpp -o /tmp/reboot-version-tests
/tmp/reboot-version-tests
```
