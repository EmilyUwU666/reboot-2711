[CmdletBinding()]
param([Parameter(Mandatory = $true)][string] $FortniteDirectory)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
. (Join-Path $PSScriptRoot 'PeFile.ps1')

try {
    if ([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT) {
        throw 'Run this installation check on the Windows PC containing Fortnite 27.11.'
    }
    $root = (Resolve-Path -LiteralPath $FortniteDirectory).Path
    $exe = Join-Path $root 'FortniteGame\Binaries\Win64\FortniteClient-Win64-Shipping.exe'
    if (-not (Test-Path -LiteralPath $exe -PathType Leaf)) {
        throw 'Select the installation root containing FortniteGame and Engine.'
    }
    $info = Get-PeFileInfo -Path $exe
    if (-not $info.IsX64 -or $info.IsDll) { throw 'The game executable is not a Windows x64 application.' }
    $version = [Diagnostics.FileVersionInfo]::GetVersionInfo($exe)
    $versionText = @($version.ProductVersion, $version.FileVersion) -join ' | '
    Write-Output "Version metadata: $versionText"
    # A metadata match is a preflight check, not a game-server compatibility test.
    if ($versionText -notmatch '(^|[^0-9.])27\.11(?=$|[^0-9.])') {
        throw 'Cannot confirm 27.11 from executable version metadata. Check the installation version before starting.'
    }
    $paks = Join-Path $root 'FortniteGame\Content\Paks'
    if (-not (Test-Path -LiteralPath $paks -PathType Container)) { throw 'The Content\Paks directory is missing.' }
    $content = @(Get-ChildItem -LiteralPath $paks -File | Where-Object { $_.Extension -in @('.pak', '.utoc') })
    if ($content.Count -eq 0) { throw 'No .pak or .utoc content files were found.' }
    Write-Output 'Preflight passed: Windows x64, 27.11 metadata and content directory found.'
    Write-Output 'File integrity, backend login and multiplayer gameplay still require testing.'
}
catch {
    Write-Error $_ -ErrorAction Continue
    exit 1
}
