[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$projectRoot = Split-Path -Parent $PSScriptRoot
. (Join-Path $PSScriptRoot 'PeFile.ps1')

try {
    if ([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT) {
        throw 'The DLL build requires Windows with Visual Studio 2022 C++ tools and a Windows SDK.'
    }
    $vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
    if (-not (Test-Path -LiteralPath $vswhere -PathType Leaf)) {
        throw 'Install Visual Studio 2022 or Build Tools 2022 with Desktop development with C++ and a Windows SDK.'
    }
    $msbuild = & $vswhere -latest -version '[17.0,18.0)' -products '*' -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -find 'MSBuild\**\Bin\MSBuild.exe' |
        Select-Object -First 1
    if ($LASTEXITCODE -ne 0 -or -not $msbuild) { throw 'Visual Studio 2022 C++ build tools were not found.' }

    Push-Location $projectRoot
    try {
        & $msbuild (Join-Path $projectRoot 'Erbium.sln') '/m' '/t:Rebuild' '/p:Configuration=Release' '/p:Platform=x64' '/nologo'
        if ($LASTEXITCODE -ne 0) { throw "MSBuild failed with exit code $LASTEXITCODE. No release package was generated." }
    }
    finally { Pop-Location }

    $dllNames = @('Reboot-27.11-Server.dll', 'Reboot-27.11-Client.dll')
    foreach ($name in $dllNames) {
        $file = Join-Path $projectRoot "build\Release\$name"
        $info = Get-PeFileInfo -Path $file
        if (-not $info.IsX64 -or -not $info.IsDll) { throw "Expected an x64 DLL: $file" }
    }
    $dist = Join-Path $projectRoot 'dist'
    $null = New-Item -ItemType Directory -Path $dist -Force
    foreach ($name in $dllNames) {
        Copy-Item -LiteralPath (Join-Path $projectRoot "build\Release\$name") -Destination $dist -Force
    }
    foreach ($name in @('SETUP.md', 'LICENSE', 'PROVENANCE.md')) {
        Copy-Item -LiteralPath (Join-Path $projectRoot $name) -Destination $dist -Force
    }
    foreach ($name in @('Check-Install.ps1', 'PeFile.ps1')) {
        Copy-Item -LiteralPath (Join-Path $PSScriptRoot $name) -Destination $dist -Force
    }
    $hashes = foreach ($name in $dllNames) {
        $hash = Get-FileHash -LiteralPath (Join-Path $dist $name) -Algorithm SHA256
        '{0}  {1}' -f $hash.Hash.ToLowerInvariant(), $name
    }
    $hashes | Set-Content -LiteralPath (Join-Path $dist 'SHA256SUMS.txt') -Encoding ASCII
    Write-Host "Built both DLLs: $dist"
    Write-Host 'Read SETUP.md. Compilation does not establish gameplay compatibility.'
}
catch {
    Write-Error $_ -ErrorAction Continue
    exit 1
}
