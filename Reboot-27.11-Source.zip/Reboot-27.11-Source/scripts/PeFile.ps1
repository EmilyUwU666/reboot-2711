Set-StrictMode -Version Latest

function Get-PeFileInfo {
    param([Parameter(Mandatory = $true)][string] $Path)
    $stream = [System.IO.File]::OpenRead($Path)
    $reader = [System.IO.BinaryReader]::new($stream)
    try {
        if ($stream.Length -lt 64 -or $reader.ReadUInt16() -ne 0x5A4D) {
            throw "Not a Windows PE file: $Path"
        }
        $stream.Position = 0x3C
        $peOffset = $reader.ReadUInt32()
        if ($peOffset -lt 64 -or ([long] $peOffset + 26) -gt $stream.Length) {
            throw "Invalid PE header offset: $Path"
        }
        $stream.Position = $peOffset
        if ($reader.ReadUInt32() -ne 0x00004550) { throw "Invalid PE signature: $Path" }
        $machine = $reader.ReadUInt16()
        $stream.Position = [long] $peOffset + 20
        $optionalHeaderSize = $reader.ReadUInt16()
        $characteristics = $reader.ReadUInt16()
        if ($optionalHeaderSize -lt 2 -or ([long] $peOffset + 24 + $optionalHeaderSize) -gt $stream.Length) {
            throw "Truncated PE optional header: $Path"
        }
        $magic = $reader.ReadUInt16()
        [pscustomobject]@{
            Machine = $machine
            IsX64 = ($machine -eq 0x8664 -and $magic -eq 0x20B)
            IsDll = (($characteristics -band 0x2000) -ne 0)
        }
    }
    finally {
        $reader.Dispose()
        $stream.Dispose()
    }
}
