@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\Build.ps1"
set "reboot_build_result=%errorlevel%"
if not "%reboot_build_result%"=="0" echo Build failed. The error is shown above.
pause
exit /b %reboot_build_result%
