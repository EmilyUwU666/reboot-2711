# Fortnite 27.11 for Reboot Launcher - experimental source project

This is a **Windows x64, Erbium-based server and client pair** configured for
Fortnite **27.11**. It plugs into Reboot Launcher's custom DLL settings. It is
not a release from the Project Reboot or Erbium maintainers.

**Status:** source prepared; Windows DLL compilation and in-game testing have
not been performed in the development environment. This is not a verified
playable release. See [VALIDATION.md](VALIDATION.md) for the exact checks run.

On a Windows PC with Visual Studio 2022 C++ tools and a Windows SDK, run
`BUILD.cmd`. The build creates `dist/Reboot-27.11-Server.dll` and
`dist/Reboot-27.11-Client.dll`. Follow [SETUP.md](SETUP.md) to select both in
Reboot Launcher.

The shared SDK checks the complete engine build string before initializing
27.11 bindings. Both DLLs reject other Fortnite releases. Server and client
retain upstream's matching Iris replication support, Season 27 map selection,
and game-phase logic. Extra startup checks report missing SDK bindings, missing
replication settings, and unavailable game objects.

The default profile is solo, port 7777, 30 ticks/second, no siphon, no infinite
ammo/materials, no late game, and no automatic restart. Configuration remains
in `Erbium/Erbium/Public/Configuration.h`; rebuild both DLLs after changing it.

Game content, a backend, and an authentication/redirect component are external
requirements. This source package does not provide them. Existing account,
login, or gameplay errors cannot be diagnosed from the version number alone.

Code and dependencies originate from Erbium. See [PROVENANCE.md](PROVENANCE.md)
and [LICENSE](LICENSE). Upstream describes newer-season support as partial.

## Upstream README

# Erbium

Erbium is a WIP universal gameserver for Fortnite.

[**Join our Discord!**](https://discord.gg/WxNEGBxfKq)

## Features
- **Version support**: Erbium supports version 3.4 (season 3) to 19.40 (chapter 3 season 1).
> Erbium also has partial support for 1.7.2 (season 0) to 3.3 (season 3) & 20.00 (chapter 3 season 2) to 30.00 (chapter 5 season 3)
- **Easy to use**: Erbium is designed to be fast & easy to configure for new users.

## To-do
- **Creative**
- **XP**
- **Quests**

## Configuration
- In order to change options, go to Erbium/Public/Configuration.h & configure to your liking!

> If you have issues with a specific version or find a bug, please make an issue.

> Contributions are highly appreciated!

> If you use this, please give me credit.
> Credit to Milxnor for parts of Finders.cpp
